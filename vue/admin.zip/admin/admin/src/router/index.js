import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

const login = reslove => require(['../components/pages/login.vue'],reslove)
const home = reslove => require(['../components/public/home.vue'],reslove)
const news = reslove => require(['../components/pages/news.vue'],reslove)
const sendnews = reslove => require(['../components/pages/sendnews.vue'],reslove)
const introduction = reslove => require(['../components/pages/introduction.vue'],reslove)
const history = reslove => require(['../components/pages/history.vue'],reslove)
const culture = reslove => require(['../components/pages/culture.vue'],reslove)
const slide = reslove => require(['../components/pages/slide.vue'],reslove)
const branch = reslove => require(['../components/pages/branch.vue'],reslove)
const release = reslove => require(['../components/pages/release.vue'],reslove)
const addadmin = reslove => require(['../components/pages/addadmin.vue'],reslove)
const record = reslove => require(['../components/pages/record.vue'],reslove)

export default new Router({
  routes: [
    {
      path:'/', 
      redirect:'/login'
    },
    {
      path:'/login', 
      name:'login',
      component:login,
      meta:{title:'管理员登录'}
    },
    { 
      path:'/home', 
      component:home,
      redirect:'/home/news',
      children:[
        { 
          path:'/home/news',
          name:'news', 
          component:news,
          meta:{title:'新闻管理',requireAuth:true} 
        },
        { 
          path:'/home/news/sendnews',
          name:'sendnews',
          component:sendnews,
          meta:{title:'发布新闻',requireAuth:true}
        },
        { 
          path:'/home/introduction', 
          name:'introduction',
          component:introduction,
          meta:{title:'企业简介',requireAuth:true} 
        },
        { 
          path:'/home/history',
          name:'history',
          component:history,
          meta:{title:'公司历程',requireAuth:true}
        },
        {
          path:'/home/culture',
          name:'culture', 
          component:culture,
          meta:{title:'公司文化',requireAuth:true} 
        },
        { 
          path:'/home/slide',
          name:'slide',
          component:slide,
          meta:{title:'首页轮播',requireAuth:true} 
        },
        { 
          path:'/home/branch', 
          name:'branch',
          component:branch,
          meta:{title:'部门管理',requireAuth:true} 
        },
        { 
          path:'/home/release',
          name:'release',
          component:release,
          meta:{title:'职位发布',requireAuth:true}
        },
        { 
          path:'/home/addadmin',
          name:'addadmin',
          component:addadmin,
          meta:{title:'添加管理员',requireAuth:true}
        },
        { 
          path:'/home/record',
          name:'record',
          component:record,
          meta:{title:'查看记录',requireAuth:true} 
        }
      ]
    }
  ]
})
