<template>
  <div id="app">
    <router-view></router-view>
  </div>
</template>
<script>
  export default {
    name: 'app'
  }
</script>
<style>
  @import './assets/font/iconfont.css';
</style>
<style lang="less">
  @import './assets/css/reset.less';
  @import './assets/css/main.less';
</style>

