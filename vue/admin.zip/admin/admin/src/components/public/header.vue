<template>
    <div class="header clearfix">
        <div class="logo fl">
            <router-link :to="'/home'">
                <img src="../../assets/img/logo.png" alt="荣佑控股管理后台">
            </router-link>
        </div>
        <div class="user-info fr">
            <el-dropdown trigger="click" @command="loginout">
                <span class="el-dropdown-link">
                    <img src="../../assets/img/logoicon.png" class="adminlogo img-responsive" alt="管理员头像">
                    <i>{{uname}}</i>
                </span>
                <el-dropdown-menu slot="dropdown">
                    <el-dropdown-item command="out">安全退出</el-dropdown-item>
                </el-dropdown-menu>
            </el-dropdown>
        </div>
    </div>
</template>
<script>
    export default{
        name:'header',
        computed: {
            uname(){
                return window.localStorage.getItem('uname')
            }
        },
        methods: {
            loginout(command){
                if(command=='out'){
                    window.localStorage.removeItem('uname')
                    this.$router.push({path:'/login'})
                    this.$message({
                        message:'退出登录成功！',
                        duration:1500
                    })
                }
            }
        }
    }
</script>
<style lang="less" scoped>
    @import '../../assets/css/main.less';
    .header{
        box-sizing:@borderbox;
        height:@width*0.7;
        padding:0px @width*0.5;
        background:#1F2D3D;
        position:relative;
        .logo{padding:8px 0px;}
        .user-info{
            .el-dropdown{
                height:@width*0.7;
                line-height:@width*0.7;
            }
            .el-dropdown-link{
                color:#fff;
                cursor:pointer;
                .adminlogo{
                    display:inline-block;
                    margin-right:10px;
                    width:@width*0.5;
                    height:@width*0.5;
                    border-radius:50%;
                    -webkit-border-radius:50%;
                }
            }
        }
    }
</style>
