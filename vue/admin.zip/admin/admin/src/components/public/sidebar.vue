<template>
    <div class="sidebar">
        <el-row class="tac">
            <el-col>
                 <el-menu  class="el-menu-vertical-demo" theme="dark" unique-opened router>
                    <template v-for="(item,index) in menus">
                        <template v-if="item.subs">
                            <el-submenu :index="item.href">
                                <template slot="title"><i :class="item.icon"></i>{{item.title}}</template>
                                <template v-for="(item2,index2) in item.subs">
                                    <template v-if="item2.three">
                                        <el-submenu :index="item2.href">
                                            <template slot="title">{{item2.title}}</template>
                                            <template v-for="(item3,index) in item2.three">
                                                <el-menu-item :index="item3.href">{{item3.title}}</el-menu-item>
                                            </template>
                                        </el-submenu>
                                    </template>
                                    <template v-else>
                                        <el-menu-item-group>
                                            <el-menu-item :index="item2.href">{{item2.title}}</el-menu-item>
                                        </el-menu-item-group>
                                    </template>
                                </template>
                            </el-submenu>
                        </template>
                        <template v-else>
                            <el-menu-item :index="item.href"><i :class="item.icon"></i>{{item.title}}</el-menu-item>
                        </template>
                    </template>
                </el-menu>
            </el-col>
        </el-row>
    </div>
</template>
<script>
    export default{
        data () {
            return {
                menus:[
                    {
                        icon:'icon iconfont icon-fabu3',
                        href:'1',
                        title:'数据发布',
                        subs: [
                            {
                                href:'/home/slide',
                                title:'首页轮播'
                            },
                            {
                                href:'/home/news',
                                title:'新闻管理'
                            },
                            {
                                href:'/home/introduction',
                                title:'企业简介'
                            },
                            {
                                href:'/home/history',
                                title:'公司历程'
                            },
                            {
                                href:'/home/culture',
                                title:'公司文化'
                            }
                        ]
                    },
                    {
                        icon:'icon iconfont icon-gerenzhongxin',
                        href:'2',
                        title:'职位管理',
                        subs: [
                            {
                                href:'/home/branch',
                                title:'部门管理'
                            },
                            {
                                href:'/home/release',
                                title:'职位发布'
                            }
                        ]
                    },
                    {
                        icon:'icon iconfont icon-gerenzhongxin',
                        href:'3',
                        title:'个人中心',
                        subs: [
                            {
                                href:'/home/addadmin',
                                title:'添加管理员'
                            },
                            {
                                href:'/home/record',
                                title:'查看记录'
                            }
                        ]
                    }
                ]
            }
        }
    }
</script>
<style lang="less" scoped>
    .sidebar{
        display:block;
        position:absolute;
        top:70px;
        left:0px;
        bottom:0px;
        width:250px;
        height:auto;
        background:#324157;
        overflow-y:auto;
    }
</style>