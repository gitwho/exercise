<template>
    <transition name="toast">
        <div class="loading" v-if="show" :style="{'z-index':zIndex}">
            <div class="loading-content">
                <slot></slot>
            </div>
        </div>
    </transition>
</template>
<script>
    export default{
        name:'loading',
        props:{
            zIndex:{
                type:Number,
                default:100
            }
        },
        data () {
            return {
                show:true
            }
        }
    }
</script>
<style lang="less" scoped>
    .loading{
        position:absolute;
        top:0px;
        left:0px;
        right:0px;
        bottom:0px;
        background:hsla(0,0%,100%,.9);
        .loading-content{
            position:absolute;
            top:50%;
            left:50%;
            margin-top:-70px;
            margin-left:-70px;
            width:110px;
            height:110px;
            padding:15px;
            border-radius:10px;
            -webkit-border-radius:10px;
        }
    }
    .toast-enter-active,.toast-leave-active{
        transition:background 0.35s;
    }
    .toast-enter,.toast-leave{
        background:#fff;
    }
</style>
