<template>
    <div class="wrapper">
        <vheader></vheader>
        <vsidebar></vsidebar>
        <div class="content">
            <transition>
                <router-view></router-view>
            </transition>
        </div>
    </div>
</template>
<script>
    import vheader from './header.vue'
    import vsidebar from './sidebar.vue'
    export default{
        name:'wrapper',
        components: {
            vheader,vsidebar
        }
    }
</script>