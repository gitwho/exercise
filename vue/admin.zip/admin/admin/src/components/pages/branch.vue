<template>
  <div class="branch">我是部门管理页面</div>
</template>
