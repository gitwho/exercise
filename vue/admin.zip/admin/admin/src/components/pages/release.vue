<template>
  <div class="release">我是职位发布页面</div>
</template>
