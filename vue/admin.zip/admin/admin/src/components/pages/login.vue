<template>
    <div class="login-wrap">
        <div class="login-model">
            <el-form :model="ruleform" :rules="rules" ref="ruleform" label-width="60px" class="demo-ruleForm" label-position="left">
                <el-form-item label="账号" prop="uname">
                    <el-input type="text" icon="icon iconfont icon-iconuser" v-model="ruleform.uname" placeholder="请输入你的姓名"></el-input>
                </el-form-item>
                <el-form-item label="密码" prop="psd">
                    <el-input type="password" icon="icon iconfont icon-unie614" v-model="ruleform.psd" placeholder="请输入你的密码"></el-input>
                </el-form-item>
                <div class="login-bth btnblock">
                    <el-button type="primary" @click="submitform('ruleform')">登录</el-button>
                </div>
            </el-form>
        </div>
    </div>
</template>
<script>
    export default{
        data () {
            var testuname = (rule,value,callback) => {
                if(value===''){
                    callback(new Error('请输入你的姓名'))
                }else if(!(/^[\u4e00-\u9fa5]{2,4}$/.test(value))){
                    callback(new Error('请输入2-4位的汉字姓名'))
                }else{
                  callback()  
                }
            }
            var testpsd = (rule,value,callback) =>{
                if(value===''){
                    callback(new Error('请输入密码'))
                } else if(!(/^[0-9a-zA-z]{6,12}$/.test(value))){
                    callback(new Error('请输入6-12位字母或数字组合'))
                }else{
                    callback()
                }
            }
            return {
                ruleform:{
                    uname:'',
                    psd:''
                },
                rules:{
                    uname:[
                        {validator:testuname,trigger:'blur'}
                    ],
                    psd:[
                        {validator:testpsd,trigger:'blur'}
                    ]
                }
            }
        },
        methods: {
            submitform(refname){
                this.$refs[refname].validate((result) => {
                    if(result){
                        this.$message({
                            duration:1500,
                            message: '登录成功',
                            type: 'success'
                        });
                        window.localStorage.setItem('uname',this.ruleform.uname)
                        this.$router.push({path:'/home'})
                    }else{
                        this.$message({
                            duration:1500,
                            message:'账号或密码输入有误',
                            type:'error'
                        })
                    }
                })
            }
        }
    }
</script>
<style lang="less" scoped>
    @import '../../assets/css/main.less';
    .login-wrap{
        position:relative;
        width:100%;
        height:100%;
        background:url('../../assets/img/adminbg.png') no-repeat center center;
        background-size:100% 100%;
        .login-model{
            box-sizing:@borderbox;
            position:absolute;
            top:10%;
            left:50%;
            width:610px;
            height:544px;
            padding:270px 100px 0px 100px;
            margin-left:-305px;
            background:url('../../assets/img/loginbg.png') no-repeat center center;
            border-radius:4px;
            
        }
    }
</style>