<template>
    <div class="record">我是查看记录页面</div>
</template>
