<template>
    <div class="culture">我是企业文化</div>
</template>
