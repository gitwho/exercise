<template>
    <div class="news">
        <div class="crumbs padding15">
            <el-breadcrumb separator="/">
                <el-breadcrumb-item><i class="icon iconfont icon-gerenzhongxin"></i>新闻管理</el-breadcrumb-item>
            </el-breadcrumb>
        </div>
        <div class="handle-box padding15">
            <router-link :to="'/home/news/sendnews'" class="el-button el-button--primary">
                <i class="el-icon-edit"></i>发布新闻
            </router-link>
        </div>
        <div class="table-data padding15">
            <template>
                <el-table :data="tableData" border style="width:100%" :default-sort="{prop:'date',order:'descending'}" :empty-text="empty">
                     <!--<el-table-column type="expand">
                        <template scope="scope">
                            <el-form label-position="left" inline class="demo-table-expand">
                                <el-form-item label="作者">
                                    <span>{{ scope.row.author }}</span>
                                </el-form-item>
                                <el-form-item label="出处">
                                    <span>{{ scope.row.quarry }}</span>
                                </el-form-item>
                                <el-form-item label="类型">
                                    <span>{{ scope.row.type}}</span>
                                </el-form-item>
                                <el-form-item label="文章标题">
                                    <span>{{ scope.row.name}}</span>
                                </el-form-item>
                                <el-form-item label="发布时间">
                                    <span>{{ scope.row.date }}</span>
                                </el-form-item>
                                <el-form-item label="操作">
                                    <el-button size="small" type="primary" icon="edit">编辑</el-button>
                                    <el-button size="small" type="info" icon="document">查看</el-button>
                                    <el-button size="small" type="danger" icon="delete" @click="handleDelete(scope.$index, scope.row)">删除</el-button>
                                </el-form-item>
                            </el-form>
                        </template>
                    </el-table-column>-->
                    <el-table-column prop="author" label="作者" width="100"></el-table-column>
                    <el-table-column prop="quarry" label="出处" width="100"></el-table-column>
                    <el-table-column prop="type" label="类型" width="100"></el-table-column>
                    <el-table-column prop="name" label="文章标题" width="200"></el-table-column>
                    <el-table-column prop="date" label="发布时间" sortable width="150"></el-table-column>
                    <el-table-column label="操作">
                        <template scope="scope">
                            <el-button size="small" type="primary" icon="edit">编辑</el-button>
                            <el-button size="small" type="info" icon="document">查看</el-button>
                            <el-button size="small" type="danger" icon="delete" @click="handleDelete(scope.$index, scope.row)">删除</el-button>
                        </template>
                    </el-table-column>
                </el-table>
            </template>
            <loading v-if="loading">
                <div class="loading-animate">
                    <RingLoader :color="style"></RingLoader>
                </div>
                <div class="loading-msg">{{loadingmsg||'数据加载中....'}}</div>
                </slot>
            </loading>
        </div>
        <el-row type="flex" class="row-bg pagination paddingtop15" justify="center">
            <template v-if="tableData.length>0">
                <el-pagination @current-change="handleCurrentChange" :current-page.sync="currentPage3"
                :page-size="pagesize" layout="prev, pager, next, jumper" :total="totalnum">
                </el-pagination>
            </template>
        </el-row>
    </div>
</template>
<script>
    import loading from '../public/loading.vue'
    import RingLoader from 'vue-spinner/src/RingLoader.vue'
    export default {
        name:'news',
        data () {
            return {
                loading:true,// 控制loading显示隐藏
                style:'#20a0ff',// loading 加载圆球颜色
                loadingmsg:'',// 加载文字空则是数据加载中
                empty:'暂无数据',//table表无数据时显示
                currentPage3:1,//当前页数
                totalnum:4,//总记录数
                pagesize:10,//每页条数
                tableData: [
                    {
                        author:'王开祥',
                        quarry:'荣佑集团',
                        type:'企业新闻',
                        name: '荣佑控股荣获A轮融资',
                        date: '2017-05-05',
                    },{
                        author:'王开祥',
                        quarry:'荣佑集团',
                        type:'社会新闻',
                        name: '荣佑控股荣获B轮融资',
                        date: '2017-05-04',
                    },{
                        author:'王开祥',
                        quarry:'荣佑集团',
                        type:'社会新闻',
                        name: '荣佑控股荣获C轮融资',
                        date: '2017-05-03',
                    },{
                        author:'王开祥',
                        quarry:'荣佑集团',
                        type:'企业新闻',
                        name: '荣佑控股荣获D轮融资',
                        date: '2017-05-02'
                    }
                ]
            }
        },
        components: {
           loading,
           RingLoader
        },
        mounted () {
            if(this.tableData.length>0){
                this.loading=false
            }
        },
        methods: {
            handleDelete(index,row){
                this.$confirm('确定永久删除'+row.name+'这篇文章吗', '是否继续?', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    this.tableData.splice(index,1)
                    this.$message({
                        type: 'success',
                        message: '删除成功!'
                    });
                }).catch(() => {
                    this.$message({
                        type:'info',
                        message:'已取消删除'
                    });          
                });
            },
            handleCurrentChange(val) {
                console.log(`当前页: ${val}`);
            }
        }
    }
</script>
<style lang="less" scoped>
    .table-data{position:relative;}
</style>

