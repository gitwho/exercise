<template>
    <div class="slide">我是首页轮播</div>
</template>
