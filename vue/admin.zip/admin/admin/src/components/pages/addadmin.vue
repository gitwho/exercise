<template>
    <div class="addadmin">
        <div class="crumbs padding15">
            <el-breadcrumb separator="/">
                <el-breadcrumb-item><i class="icon iconfont icon-gerenzhongxin"></i>添加管理员</el-breadcrumb-item>
            </el-breadcrumb>
        </div>
        <el-row class="form-box padding15" type="flex" justify="center">
            <el-col :lg="10" :md="16" :sm="20">
                <el-form ref="ruleform" :model="ruleform" :rules="rulesform" label-width="80px" class="demo-ruleForm" label-position="left" :lg="4">
                    <el-form-item label="添加姓名" prop="uname">
                        <el-input type="text" v-model="ruleform.uname" icon="icon iconfont icon-iconuser" placeholder="请输入你的姓名"></el-input>
                    </el-form-item>
                    <el-form-item label="添加密码" prop="upsd">
                        <el-input type="password" v-model="ruleform.upsd" icon="icon iconfont icon-unie614" placeholder="请输入你的密码"></el-input>
                    </el-form-item>
                    <div class="login-bth btnblock">
                        <el-button type="primary" @click="submitform('ruleform')">登录</el-button>
                    </div>
                </el-form>
            </el-col>
        </el-row>
    </div>
</template>
<script>
    export default {
        name:'form-box',
        data () {
            var testuname=(rule,value,callback) => {
                if(value==''){
                    callback(new Error('请输入你的姓名'))
                }else if(!(/^[\u4e00-\u9fa5]{2,4}$/.test(value))){
                    callback(new Error('请输入2-4位的汉字姓名'))
                }else{
                    callback()
                }
            }
            var testupsd=(rule,value,callback) => {
                if(value==''){
                     callback(new Error('请输入密码'))
                }else if(!(/^[0-9a-zA-z]{6,12}$/.test(value))){
                    callback(new Error('请输入6-12位字母或数字组合'))
                }else{
                    callback()
                }
            }
            return {
               ruleform:{
                   uname:'',
                   upsd:''
               },
               rulesform:{
                    uname:[
                        {validator:testuname,trigger:'blur'}
                    ],
                    upsd:[
                        {validator:testupsd,trigger:'blur'}
                    ]
               }
            }
        },
        methods: {
            submitform(refname){
                this.$refs[refname].validate((bool) => {
                    if(bool){
                        this.$message({
                            message:'验证成功',
                            type:'success',
                            duration:1500
                        })
                    }else{
                        this.$message({
                            message:'账号密码输入有误',
                            type:'error',
                            duration:1500
                        })
                    }
                })
            }
        }
    }
</script>

