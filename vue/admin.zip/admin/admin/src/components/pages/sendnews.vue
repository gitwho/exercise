<template>
  <div class="sendnews">
    <div class="crumbs padding15">
        <el-breadcrumb separator="/">
            <el-breadcrumb-item :to="{path:'/home/news'}"><i class="icon iconfont icon-gerenzhongxin"></i>新闻管理</el-breadcrumb-item>
            <el-breadcrumb-item>发布新闻</el-breadcrumb-item>
        </el-breadcrumb>
    </div>
  </div>
</template>
